from django.apps import AppConfig


class PlayerInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'player_info'
